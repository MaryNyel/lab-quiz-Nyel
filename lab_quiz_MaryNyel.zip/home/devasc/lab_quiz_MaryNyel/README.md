The project's purpose is to study the subject and test the knowledge of the students.
